# InterfaceCapteur
Projet L3-EEA, conception et réalisation d'un circuit analogique pour retourner sur commande la distance par rapport à un obstacle avec une tension.

# Rapport (LaTex)


# Schéma (LTspice & KiCad)

# Simulation (LTspice)

# Réalisation (Kicad/breadbord/PCBA)
